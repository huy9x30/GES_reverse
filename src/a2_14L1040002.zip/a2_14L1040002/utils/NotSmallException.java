package utils;

public class NotSmallException extends RuntimeException {
  public NotSmallException(String msg) {
    super(msg);
  }
}
